import React from 'react';
import {  Text, View } from 'react-native';
import {createAppContainer}from 'react-navigation';
import {createBottomTabNavigator} from 'react-navigation-tabs';
import FbScreen from './Screens/fb';
import InstaScreen from './Screens/insta';


export default class App extends React.Component {
  render(){
  return (
<AppContainer/>
  );
  }
}

const Tabs = createBottomTabNavigator({
 Facebook:{screen: FbScreen},
 Instagram:{screen: InstaScreen}
})

const AppContainer = createAppContainer(Tabs);

