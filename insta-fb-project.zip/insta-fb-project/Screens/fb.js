import React from 'react';
import {Text,View,StyleSheet,TextInput,TouchableOpacity} from 'react-native';

export default class ReadScreen extends React.Component{
   render(){
        return(
            <View style={{justifyContent:'center',flex:1,alignItems:'center'}}>
            <TextInput
                maxLength={200}
                multiline
                numberOfLines={4}
                style={styles.inputBox}
            />
            <TouchableOpacity >
                <Text style={styles.uploadButton}>Upload To Facebook</Text>
                </TouchableOpacity>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    inputBox:{
        width:"90%",
        height:"50%",
        borderWidth: 2,
      },
   uploadButton:{
        width:"50%",
        height:55,
        margin:10,
        padding:10,
        alignItems:'center',
        fontWeight:'bold',
        color:"brown"
    },
    
        
    
})
        
    
